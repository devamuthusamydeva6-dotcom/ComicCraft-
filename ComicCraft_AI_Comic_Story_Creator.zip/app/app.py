import os
import json
import html
import streamlit as st
from google import genai
from google.genai import types
from pydantic import BaseModel, Field
from typing import List

st.set_page_config(page_title="ComicCraft", page_icon="🦸", layout="wide")

class Panel(BaseModel):
    panel_number: int
    scene: str = Field(description="Visual description of the comic panel")
    narration: str = Field(description="Short narration text")
    dialogue: str = Field(description="Short dialogue for the panel")
    characters: List[str]

class Comic(BaseModel):
    title: str
    genre: str
    logline: str
    characters: List[str]
    panels: List[Panel]
    ending: str
    moral: str

def get_client():
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return None
    return genai.Client(api_key=api_key)

def generate_comic(topic, genre, characters, panels, audience):
    client = get_client()
    if client is None:
        raise RuntimeError("GEMINI_API_KEY is not configured.")

    prompt = f"""
Create an original short comic story.

Topic/idea: {topic}
Genre: {genre}
Main characters: {characters or "Create suitable characters"}
Number of panels: {panels}
Target audience: {audience}

Requirements:
- Give the comic a catchy title and one-sentence logline.
- Keep the story coherent from panel 1 to the final panel.
- Each panel must contain a concise visual scene description, narration,
  dialogue, and the characters present.
- Keep dialogue short enough for a comic speech bubble.
- Avoid copyrighted characters, existing franchises, and copied plots.
- End with a clear resolution and a simple moral/lesson.
"""

    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL", "gemini-3.8-flash"),
        contents=prompt,
        config=types.GenerateContentConfig(
            temperature=0.9,
            max_output_tokens=5000,
            response_mime_type="application/json",
            response_schema=Comic,
        ),
    )
    return Comic.model_validate_json(response.text)

def comic_html(comic):
    cards = []
    for p in comic.panels:
        cards.append(f"""
        <div class="panel">
          <div class="panel-head">Panel {p.panel_number}</div>
          <div class="scene">🎨 {html.escape(p.scene)}</div>
          <div class="narration">📖 {html.escape(p.narration)}</div>
          <div class="dialogue">💬 “{html.escape(p.dialogue)}”</div>
          <div class="characters">👥 {html.escape(", ".join(p.characters))}</div>
        </div>
        """)
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{html.escape(comic.title)}</title>
<style>
body{{font-family:Arial,sans-serif;background:#f4f4f4;margin:0;padding:30px}}
.container{{max-width:1000px;margin:auto}}
h1{{font-size:42px;margin-bottom:5px}}
.logline{{font-size:18px;color:#444;margin-bottom:25px}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}
.panel{{background:white;border:3px solid #111;border-radius:16px;padding:18px;box-shadow:5px 5px 0 #111}}
.panel-head{{font-weight:bold;font-size:22px;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:12px}}
.scene{{background:#eee;padding:12px;border-radius:10px;margin-bottom:10px}}
.narration{{font-style:italic;margin-bottom:10px}}
.dialogue{{font-weight:bold;margin-bottom:10px}}
.characters{{font-size:13px;color:#555}}
@media(max-width:700px){{.grid{{grid-template-columns:1fr}}}}
</style></head>
<body><div class="container">
<h1>🦸 {html.escape(comic.title)}</h1>
<div class="logline">{html.escape(comic.logline)}</div>
<div class="grid">{''.join(cards)}</div>
<h2>Ending</h2><p>{html.escape(comic.ending)}</p>
<h2>Moral</h2><p>{html.escape(comic.moral)}</p>
</div></body></html>"""

st.title("🦸 ComicCraft")
st.subheader("AI Comic Story Creator using Gemini Models")
st.write("Turn a simple idea into a structured multi-panel comic story.")

with st.sidebar:
    st.header("Comic Settings")
    topic = st.text_area("Story idea", "A shy student discovers a tiny robot that can repair broken things.", height=100)
    genre = st.selectbox("Genre", ["Adventure", "Comedy", "Fantasy", "Science Fiction", "Mystery", "Educational"])
    characters = st.text_input("Characters", "Maya, Robo")
    panel_count = st.slider("Number of panels", 3, 10, 6)
    audience = st.selectbox("Audience", ["Children", "School students", "General audience"])
    generate = st.button("✨ Generate Comic", use_container_width=True)

if "comic" not in st.session_state:
    st.session_state.comic = None

if generate:
    if not topic.strip():
        st.error("Please enter a story idea.")
    else:
        with st.spinner("Gemini is creating your comic..."):
            try:
                st.session_state.comic = generate_comic(
                    topic, genre, characters, panel_count, audience
                )
            except Exception as e:
                st.error(f"Could not generate the comic: {e}")

comic = st.session_state.comic

if comic:
    st.success("Comic generated successfully!")
    st.header(comic.title)
    st.write(f"**Genre:** {comic.genre}")
    st.write(f"**Logline:** {comic.logline}")

    for panel in comic.panels:
        with st.container(border=True):
            st.markdown(f"### Panel {panel.panel_number}")
            st.write(f"**Scene:** {panel.scene}")
            st.write(f"**Narration:** {panel.narration}")
            st.write(f"**Dialogue:** 💬 {panel.dialogue}")
            st.caption("Characters: " + ", ".join(panel.characters))

    st.divider()
    st.subheader("Ending")
    st.write(comic.ending)
    st.subheader("Moral")
    st.write(comic.moral)

    data = comic.model_dump_json(indent=2)
    st.download_button(
        "⬇️ Download Comic JSON",
        data=data,
        file_name="comiccraft_output.json",
        mime="application/json",
    )

    page = comic_html(comic)
    st.download_button(
        "🌐 Download Comic HTML",
        data=page,
        file_name="comiccraft.html",
        mime="text/html",
    )
else:
    st.info("Enter a story idea in the sidebar and click **Generate Comic**.")
    st.markdown("""
    ### How it works
    1. User enters a story idea and comic settings.
    2. The application sends a structured prompt to Gemini.
    3. Gemini generates title, characters and panel-by-panel story data.
    4. The application displays the comic storyboard.
    5. The user can download the generated story as JSON or HTML.
    """)
