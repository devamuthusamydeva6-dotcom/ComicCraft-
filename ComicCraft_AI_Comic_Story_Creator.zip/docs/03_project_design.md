# Phase 3 - Project Design

## System Architecture

```text
+----------------------+
|      User            |
| Story + Settings     |
+----------+-----------+
           |
           v
+----------------------+
|   Streamlit UI       |
+----------+-----------+
           |
           v
+----------------------+
| Prompt Builder       |
+----------+-----------+
           |
           v
+----------------------+
| Gemini Model         |
| Structured Output    |
+----------+-----------+
           |
           v
+----------------------+
| Pydantic Validation  |
+----------+-----------+
           |
           v
+----------------------+
| Comic Storyboard UI  |
+----------+-----------+
       |           |
       v           v
    JSON          HTML
   Download      Download
```

## Data Model

Comic:
- title
- genre
- logline
- characters
- panels
- ending
- moral

Panel:
- panel_number
- scene
- narration
- dialogue
- characters

## UI Design
Sidebar:
- Story idea
- Genre
- Characters
- Number of panels
- Audience
- Generate button

Main area:
- Title
- Logline
- Panels
- Ending
- Moral
- Download buttons
