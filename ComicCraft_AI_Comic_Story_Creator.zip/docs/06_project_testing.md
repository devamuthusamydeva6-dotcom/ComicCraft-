# Phase 6 - Project Testing

## Test Case 1 - Valid Story Idea
Input: A student discovers a tiny robot.
Expected: A complete multi-panel comic is generated.
Result: Pass when title, panels, dialogue and ending are displayed.

## Test Case 2 - Different Genre
Input: Same idea, Mystery genre.
Expected: Story tone changes to mystery.
Result: Pass when generated output follows the selected genre.

## Test Case 3 - Panel Count
Input: 3 panels.
Expected: Approximately 3 panels are generated.
Result: Pass when the requested panel count is respected.

## Test Case 4 - Empty Story Idea
Input: Empty.
Expected: Application asks user to enter an idea.
Result: Pass.

## Test Case 5 - Missing API Key
Input: No Gemini API key.
Expected: Clear error message.
Result: Pass.

## Test Case 6 - Export
Action: Click JSON/HTML download.
Expected: File downloads successfully.
Result: Pass.
