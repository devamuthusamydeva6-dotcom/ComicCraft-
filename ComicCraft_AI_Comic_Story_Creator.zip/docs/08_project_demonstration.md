# Phase 8 - Project Demonstration

## Demo Flow

1. Open the ComicCraft application.
2. Explain the project title.
3. Explain the problem: comic creation requires several manual steps.
4. Explain the solution: Gemini creates a structured comic storyboard.
5. Enter a sample story idea.
6. Select a genre.
7. Enter characters.
8. Select the number of panels.
9. Click Generate Comic.
10. Show the generated title and logline.
11. Scroll through all panels.
12. Explain scene, narration and dialogue.
13. Show the ending and moral.
14. Demonstrate JSON download.
15. Demonstrate HTML download.

## Suggested Voice-Over
"Good morning. Our project is ComicCraft, an AI Comic Story Creator using Gemini Models. The purpose of this project is to help users convert a simple story idea into a structured comic storyboard. The user provides a topic, genre, characters and number of panels. The application sends these details to the Gemini model and receives structured comic data. The application validates the response and displays each panel with scene description, narration and dialogue. Finally, the user can download the comic as JSON or HTML."
