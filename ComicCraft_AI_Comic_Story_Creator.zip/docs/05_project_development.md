# Phase 5 - Project Development

## Modules

### 1. User Interface
Streamlit provides the input form and output page.

### 2. Gemini Integration
The Google GenAI Python SDK sends the story prompt to a Gemini model.

### 3. Structured Output
The response is requested as JSON matching the Comic/Pydantic schema. This makes the generated information easier for the application to validate and display.

### 4. Storyboard Rendering
The validated data is displayed panel-by-panel.

### 5. Export
The generated result can be downloaded as JSON or as a standalone HTML file.

## Development Result
The working implementation is available in `app/app.py`.
